package mahasiswa;

/**
 *
 * @author User
 */
public class Mahasiswa {

   
    public static void main(String[] args) {
        new Absensi().setVisible(true);
    }
    
}
